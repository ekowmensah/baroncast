<?php
// Main entry point - redirect to voter dashboard
header('Location: ./voter/');
exit();
?>
