<?php
// Redirect to the correct commission settings page
header('Location: commission-settings.php');
exit;
?>
