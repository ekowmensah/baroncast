<?php
// Redirect to the correct withdrawal page
header('Location: withdrawal.php');
exit;
?>
